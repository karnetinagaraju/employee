import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../shared/employee.services';
import { Employee } from '../../shared/employee.model';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {
  empID: number;
  employees: Employee[] ;
  filteredEmployees: Employee[];

  private _searchTerm: string;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(value: string) {
    this._searchTerm = value;
    this.filteredEmployees = this.filtereEmployees(value);
  }

  filtereEmployees(serachString: string) {
console.log('inside the filtereEmployees ');
    return this.employees.filter(employee =>
    employee.username.toLowerCase().indexOf(serachString.toLowerCase()) !== -1
     || employee.address.toLowerCase().indexOf(serachString.toLowerCase()) !== -1);
  }

  constructor(private _employeeSerivcie: EmployeeService,
    private router: Router, private location: Location,
    private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.getAllEmployees();
  }

  getAllEmployees() {
    this._employeeSerivcie.showAllEmployees()
      .subscribe(
        (employees: any[]) => {
          console.log(employees);
          this.employees = employees;
          this.filteredEmployees = this.employees;
        }
      );
  }

  onDelete(empID) {
    console.log('emp id is is' + empID);
    this._employeeSerivcie.deleteEmployee(empID)
      .subscribe(
        (data) => {
          this.getAllEmployees();
        },
        err => console.error('error is ********* ' + err),
        () => console.log('test get request')
      );
  }

}
