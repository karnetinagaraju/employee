var express = require('express');
var router = express.Router();
var url = require("url");
var dbutil = require('./dbutil');
var sequelize = dbutil.sequelize;
var Sequelize = dbutil.Sequelize;
var user = dbutil.user;




// http://localhost:3000/registerUser/createData
router.post('/createData', function(req, res){
	var query = req.body;
	var dataObj = {name: query.name,  username:query.username, email:query.email, password:query.password }
	console.log("Input ==> "+ JSON.stringify(dataObj));
	var status = {"status":"ERROR", "message":"", "error":""};
	user.create(dataObj).then(task => {
		status.status = "SUCCESS";
		status.message = "Created Record !!";
	  	res.send(status);
	}).catch((err) => {
		status.message = "Error While creating data.";
		status.error = err;
		res.send(status);
	});
});

//http://localhost:3000/registerUser/getAll
router.get('/getAll', function(req, res){
	registeremployee.findAll().then(result => {
				if(result.length > 0){
					var jsonResult = [];	
					  for(var i=0; i < result.length; i++){
						  var obj = result[i].dataValues;
						  jsonResult.push(obj);
					  }
					  //return response;
					  res.send(jsonResult);
				}else{
					res.send("No data found !!");
				}
			  
	}).catch((err) => {
			res.send('Error While getting data:'+err);
	});
});

//http://localhost:3000/user/validateUser?username=nagaraju&password=123
router.post('/validateUser', function(req, res){
	var query = req.body;
	var status = {"status":"ERROR", "message":"", "error":""};
	user.findAll({where:{username: query.username, password:query.password}}).then(result => {
				if(result.length > 0){
				      status.status = "SUCCESS";
					  status.result = result[0].dataValues;
					  
				}else{
					status.message = "No data found !!";
				}
				res.send(status);
			  
	}).catch((err) => {
			res.send('Error While getting data:'+err);
	});
});


//export this router to use in our index.js
module.exports = router;
