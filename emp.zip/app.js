var express = require('express');
var equipment_details = require('./employee.js');
var user = require('./user.js');
var bodyParser = require('body-parser');
var app = express();

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
app.use('/employee', equipment_details);
app.use('/user', user);
//run
app.listen(3000);
console.log("server started !!");