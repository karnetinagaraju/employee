var Sequelize = require('sequelize');
 //Setting up the config
var sequelize = new Sequelize('employee', 'root', 'root', {
    host: 'localhost',
    port: 3306,
    dialect: 'mysql',
	define: {
        //prevent sequelize from pluralizing table names
        freezeTableName: true
    }
});

const employee = sequelize.define('employee', { 
			employee_id:{ type: Sequelize.INTEGER, 	primaryKey: true },
			name: { type: Sequelize.STRING },
			mobile: { type: Sequelize.STRING },
			address: { type: Sequelize.STRING },
			username: { type: Sequelize.STRING },
			email: { type: Sequelize.STRING },			
			created_dttm: Sequelize.DATE,			
			updated_dttm: Sequelize.DATE
			}, 
			{ createdAt: 'created_dttm', updatedAt: 'updated_dttm', underscored: true  } );

const user = sequelize.define('user', { 
			name: { type: Sequelize.STRING },			
			email: { type: Sequelize.STRING },
			username: { type: Sequelize.STRING, primaryKey: true },
			password: { type: Sequelize.STRING },
			created_dttm: Sequelize.DATE,			
			updated_dttm: Sequelize.DATE
			}, 
			{ createdAt: 'created_dttm', updatedAt: 'updated_dttm', underscored: true  } );			
		
sequelize.authenticate().then(() => {
			console.log('Connection has been established successfully.');
	})
	.catch((err) => {
		res.send('Unable to connect to the database:'+err);
	});
//return data
module.exports = {"sequelize":sequelize, "Sequelize":Sequelize, "employee":employee, "user":user};