import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



import { EmployeeComponent } from './employee.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { DeleteEmployeeComponent } from './delete-employee/delete-employee.component';
import { AuthGuard } from '../_guards/index';
import { ListEmployeeComponent } from './list-employee/list-employee.component';


const appRoutes: Routes = [

  { path: 'employee', component: EmployeeComponent, canActivate: [AuthGuard] },
  { path: 'employee/createEmploye', component: CreateEmployeeComponent, canActivate: [AuthGuard]  },
  { path: 'employee/listEmployee', component: ListEmployeeComponent, canActivate: [AuthGuard] },
  { path: 'employee/editEmployee/:id', component: EditEmployeeComponent, canActivate: [AuthGuard] },
  { path: 'employee/deleteEmployee/:id', component: DeleteEmployeeComponent, canActivate: [AuthGuard] }
];


@NgModule({
  declarations: [

    EmployeeComponent,
    CreateEmployeeComponent,
    ListEmployeeComponent,
    EditEmployeeComponent,
    DeleteEmployeeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [ AuthGuard]

})
export class EmployeeModule { }
