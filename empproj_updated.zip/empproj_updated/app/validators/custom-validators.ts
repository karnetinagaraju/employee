import { FormArray, FormControl, FormGroup, ValidationErrors, MinLengthValidator } from '@angular/forms';

export class CustomValidators {

  static birthYear(c: FormControl): ValidationErrors {
    const numValue = Number(c.value);
    const currentYear = new Date().getFullYear();
    const minYear = currentYear - 85;
    const maxYear = currentYear - 18;
    const isValid = !isNaN(numValue) && numValue >= minYear && numValue <= maxYear;
    const message = {
      'birthyear': true
    };
    return isValid ? null : message;
  }

  static uname(c: FormControl): ValidationErrors {

    const message = {
        'uniqueName': true

    };

    const isValidName = /^[a-zA-Z]*$/.test(c.value);
 //  const isValidName = null;

    return isValidName ? null : message;


}

}

