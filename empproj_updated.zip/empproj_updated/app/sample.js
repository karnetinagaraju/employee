import { Observable } from "rxjs/Observable";

// create observable 

const simpleObservabl  = new Observable((observer) => {
    
    //observable execution
    observer.next('bla bla bla');
    observer.complete();
})

simpleObservabl.subscribe()

simpleObservabl.unsubscribe();



