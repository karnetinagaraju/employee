import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError , map} from 'rxjs/operators';

@Injectable()
export class EmployeeService {

    constructor(private http: HttpClient) {
    }

    registerUser(userdata: any) {
       return  this.http.post('http://localhost:3000/user/createData',
       userdata).pipe(catchError(this.handleError<any>('registerUser')));


    }

    verifyUser(userdata: any) {
        return  this.http.post('http://localhost:3000/user/validateUser',
        userdata);
     }

    createEmployee(employee: any) {
        return  this.http.post('http://localhost:3000/employee/createData',
         employee);
     }

     showAllEmployees() {
        return this.http.get<any[]>('http://localhost:3000/employee/getAll');
     }


    getEmployeeById(no: any) {
        return this.http.get<any>('http://localhost:3000/employee/getEmployeeByID?employee_id=' + no);
    }

    updateEmployee(employee: any) {
        return  this.http.post('http://localhost:3000/employee/updateData',
         employee);
    }

    deleteEmployee(empId: number) {

       return  this.http.post('http://localhost:3000/employee/deleteData',
       {employee_id: empId});
    }

    /*private handleError(errorResponse: HttpErrorResponse) {
        console.log('Inside hadle error');
        if (errorResponse.error instanceof ErrorEvent) {
            console.error('Client side Error', errorResponse.error.message);
        } else {
            console.error('Server side Error', errorResponse);
        }
            return throwError('This is problem with serivce');
    }*/

    /**
 * Handle Http operation that failed.
 * Let the app continue.
 * @param operation - name of the operation that failed
 * @param result - optional value to return as the observable result
 */
private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
  
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
  
      // TODO: better job of transforming error for user consumption
     // this.log(`${operation} failed: ${error.message}`);
  
      // Let the app keep running by returning an empty result.
      // return of(result as T);
      var result2:any = {};
      result2.status = "ERROR";
      result2.message = "System / Application Error";
      var httpResponse:HttpErrorResponse = null;
      if(error instanceof HttpErrorResponse){
        httpResponse = error;
        if(httpResponse.statusText){
           // result2.message = httpResponse.statusText;
        }
      }

      return of(result2);
    };
  }




}
