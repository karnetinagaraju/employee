import { Injectable, Inject } from '@angular/core';

@Injectable({

    providedIn: 'root',
}
)
export class LogoutServices {

    constructor() {

    }

     currentUser = localStorage.getItem('currentUser');


    logout() {

         this.currentUser = null;

        localStorage.removeItem('currentUser');
    }

    logIn(userResp: any) {
         this.currentUser = userResp.name;

        localStorage.setItem('currentUser', userResp.name);
    }


}
