import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StorageServiceModule} from 'angular-webstorage-service';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { HttpservComponent } from './httpserv/httpserv.component';
import {HttpService} from './httpService.services';
import { LogoutServices } from './shared/logout.services';
import { AuthGuard } from './_guards/index';
import { EmpHeaderComponent } from './emp-header/emp-header.component';
import { EmpFooterComponent } from './emp-footer/emp-footer.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { EmployeeService } from './shared/employee.services';
import { EmployeeModule } from './employee/employee.module';
import { ShowErrorsComponent } from './validators/show-errors.component';


// import { EmployeeComponent } from './employee/employee.component';
// import { CreateEmployeeComponent } from './employee/create-employee/create-employee.component';
// import { ListEmployeeComponent } from './employee/list-employee/list-employee.component';
// import { EmployeeService } from './shared/employee.services';
// import { EditEmployeeComponent } from './employee/edit-employee/edit-employee.component';
// import { DeleteEmployeeComponent } from './employee/delete-employee/delete-employee.component';



const appRoutes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },

  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent }
  // { path: 'employee', component: EmployeeComponent, canActivate: [AuthGuard] },
  // { path: 'employee/createEmploye', component: CreateEmployeeComponent, canActivate: [AuthGuard]  },
  // { path: 'employee/listEmployee', component: ListEmployeeComponent, canActivate: [AuthGuard] },
  // { path: 'employee/editEmployee/:id', component: EditEmployeeComponent, canActivate: [AuthGuard] },
  // { path: 'employee/deleteEmployee/:id', component: DeleteEmployeeComponent, canActivate: [AuthGuard] }
];


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HttpservComponent,
    RegisterComponent,
    EmpHeaderComponent,
    EmpFooterComponent,
    LoginComponent,
    ShowErrorsComponent

        // CreateEmployeeComponent,
    // ListEmployeeComponent,
    // EmployeeComponent,
    // EditEmployeeComponent,
    // DeleteEmployeeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    EmployeeModule,
    StorageServiceModule
  ],
  providers: [HttpService, EmployeeService, LogoutServices, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
