import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { RegisterComponent } from './register.component';
import { ShowErrorsComponent } from '../validators/show-errors.component';
import { EmployeeService } from '../shared/employee.services';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterComponent, ShowErrorsComponent ],
      imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        RouterModule.forRoot( []),
        ReactiveFormsModule
      ],
      providers: [ EmployeeService,
        { provide: APP_BASE_HREF, useValue : '/' }
      ]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(RegisterComponent);

      component = fixture.componentInstance; // RegisterComponent test instance
      // query for the title <h1> by CSS element selector
      //de = fixture.debugElement.query(By.css('form'));
     // el = de.nativeElement;
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should set submitted to true', async(() => {
    component.onSubmit(component.registerForm);
    console.log(' Component submit value is::' + component.submitted);
    expect(component.submitted).toBeTruthy();
  }));

});
