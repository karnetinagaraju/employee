import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup , Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { EmployeeService } from '../shared/employee.services';
import { CustomValidators } from '../validators/custom-validators';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;
  message = '';
  unamePattern = '^[a-z0-9_-]{4,20}$';
  namePattern = '^[a-zA-Z]$';
  // pwdPattern = '^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{6,12}$';
  pwdPattern = '^[a-z0-9_-]{4,20}$';
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  constructor(private _employeeService: EmployeeService,
      private router: Router) {
  }

  ngOnInit() {

    this.registerForm = new FormGroup({
      'uname': new FormControl(null,
            [ Validators.required,
              Validators.minLength(4),
              Validators.maxLength(15),
              CustomValidators.uname]),
      'email': new FormControl(null, [Validators.required, Validators.email]),
      'username': new FormControl(null, [Validators.required]),
      'password': new FormControl(null , [Validators.required])
    });
  }

onSubmit(registerForm) {
    this.submitted = true;
    console.log(this.registerForm.value);
    this._employeeService.registerUser(this.registerForm.value)
    .subscribe((response: any) => {
      if ( response.status === 'SUCCESS') {
        this.router.navigate(['/login'], { queryParams: { resultMsg: 'true' } });
      } else {
        this.message = response.message;
      }
     });
  }

}
