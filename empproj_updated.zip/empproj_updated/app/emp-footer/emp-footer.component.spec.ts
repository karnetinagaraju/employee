import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpFooterComponent } from './emp-footer.component';
import { FormsModule } from '@angular/forms';
import { AppComponent } from '../app.component';

describe('EmpFooterComponent', () => {
  let component: EmpFooterComponent;
  let fixture: ComponentFixture<EmpFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [AppComponent, EmpFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

 
});
