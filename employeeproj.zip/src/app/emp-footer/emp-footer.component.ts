import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-footer',
  templateUrl: './emp-footer.component.html',
  styleUrls: ['./emp-footer.component.css']
})
export class EmpFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
