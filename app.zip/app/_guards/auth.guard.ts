﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { LogoutServices} from '../shared/logout.services';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router,
        private _logoutServices: LogoutServices) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (this._logoutServices.currentUser != null) {
            // logged in so return true
            return true;
        }
        // not logged in so redirect to login page with the return url
        //this.router.navigate([''], { queryParams: { returnUrl: state.url }});
        this.router.navigate(['']);
        return false;
    }
}