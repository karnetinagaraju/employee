export const environment = {
  production: true,
  service_url_config: {
    appurl: 'http://localhost:3000/'
  }
};
