export class Employee {
    employee_id: number;
    name: string;
    email: string;
    username: string;
    address: string;
    mobile: String;
    password: string;
}

