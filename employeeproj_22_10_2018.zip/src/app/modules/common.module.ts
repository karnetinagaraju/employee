import { NgModule} from '@angular/core';

import { HomeComponent } from '../components/common/home/home.component';
import { RegisterComponent } from '../components/common/register/register.component';
import { LoginComponent } from '../components/common/login/login.component';
import { EmpHeaderComponent } from '../components/common/emp-header/emp-header.component';
import { EmpFooterComponent } from '../components/common/emp-footer/emp-footer.component';
import { LoginService } from '../services/login.service';
import { CommonService } from '../services/common.service';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ShowErrorsComponent } from '../components/common/validation/validation-component';
import { AuthGuard } from '../_guards';
export const appRoutes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent }
];

@NgModule({
  declarations: [
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    ShowErrorsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
   RouterModule.forRoot(appRoutes),
  ],
  providers: [CommonService, LoginService],
  exports: [ShowErrorsComponent]
})
export class CommonModule { }
