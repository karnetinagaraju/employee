import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../_guards';
import { EmployeeComponent } from '../components/employee/home/employee.component';
import { CreateEmployeeComponent } from '../components/employee/create/create-employee.component';
import { ListEmployeeComponent } from '../components/employee/list/list-employee.component';
import { EditEmployeeComponent } from '../components/employee/edit/edit-employee.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from 'src/app/modules/common.module';




export const appRoutes: Routes = [
  { path: 'employee', component: EmployeeComponent, canActivate: [AuthGuard] },
  { path: 'employee/createEmploye', component: CreateEmployeeComponent, canActivate: [AuthGuard] },
  { path: 'employee/listEmployee', component: ListEmployeeComponent, canActivate: [AuthGuard] },
  { path: 'employee/editEmployee/:id', component: EditEmployeeComponent, canActivate: [AuthGuard] },
];

@NgModule({
  declarations: [
    EmployeeComponent,
    CreateEmployeeComponent,
    ListEmployeeComponent,
    EditEmployeeComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [AuthGuard],
  exports: []
})
export class EmployeeModule { }
