import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AuthGuard } from './_guards';
import { EmployeeModule } from './modules/employee.module';
import { CommonModule } from './modules/common.module';
import { EmpHeaderComponent } from './components/common/emp-header/emp-header.component';
import { EmpFooterComponent } from './components/common/emp-footer/emp-footer.component';
import { LoginService } from './services/login.service';
import { TestComponent } from './test/test.component';
import { AppLoginComponent } from './tesing_code/app-login.component';
import { LogService } from './tesing_code/log.service';




@NgModule({
  declarations: [
    AppComponent,
    EmpHeaderComponent,
    EmpFooterComponent,
    TestComponent,
    AppLoginComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([]),
    HttpClientModule,
    CommonModule,
    EmployeeModule
  ],
  providers: [ AuthGuard, LoginService, LogService],
  bootstrap: [AppComponent]
})
export class AppModule { }
