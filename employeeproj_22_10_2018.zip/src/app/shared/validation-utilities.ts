import { FormControl, ValidationErrors} from '@angular/forms';
export class CustomValidators {
  static onlyAlphabet(inpCntrl: FormControl): ValidationErrors {
    const message = { 'onlyAlphabet': true };
    const isValid = /^[a-zA-Z]*$/.test(inpCntrl.value);
    return isValid ? null : message;
  }
}

