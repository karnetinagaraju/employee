import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomValidators } from '../../../shared/validation-utilities';
import { CommonService } from '../../../services/common.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  message = '';

  constructor(private commnService: CommonService,
    private router: Router) {
  }

  ngOnInit() {
    this.registerForm = new FormGroup({
      'name': new FormControl(null,
        [Validators.required,
        Validators.minLength(4),
        Validators.maxLength(15),
        CustomValidators.onlyAlphabet]),
      'email': new FormControl(null, [Validators.required, Validators.email]),
      'username': new FormControl(null, [Validators.required]),
      'password': new FormControl(null, [Validators.required])
    });
  }

  onSubmit() {
    this.message = '';
    const resp: any = this.commnService.invokeRestServiceCall('user/createData', true, this.registerForm.value);
    resp.subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.router.navigate(['/login'], { queryParams: { registrationSuccess: true }});
        } else {
          this.message = response.message;
        }
      });
  }

}
