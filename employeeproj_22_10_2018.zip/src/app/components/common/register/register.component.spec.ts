import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { APP_BASE_HREF, CommonModule, Location } from '@angular/common';
import { RegisterComponent } from './register.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ShowErrorsComponent } from '../validation/validation-component';
import { CommonService } from '../../../services/common.service';
import { of } from 'rxjs';
// import { appRoutes } from '../../../modules/common.module';
import { Router } from '@angular/router';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;
  const commonServiceSpy =
    jasmine.createSpyObj('CommonService', ['invokeRestServiceCall']);
    const mockResponse  = {status: 'SUCCESS', result: { name: 'Admin'}};
    const mockResponse2  = {status: 'ERROR', message: 'System/Application Error'};
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

    beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RegisterComponent, ShowErrorsComponent],
      imports: [
        BrowserModule,
        FormsModule,
        CommonModule,
        /*RouterTestingModule.withRoutes(appRoutes),*/
        ReactiveFormsModule
      ],
      providers: [{ provide: CommonService, useValue: commonServiceSpy },
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: Router,      useValue: routerSpy }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // Component Should be created
  it('Component Should be created', async(() => {
    expect(component).toBeTruthy();
  }));

   // Registration submission success
   it(' Registration submission sucess', async(() => {
    /*commonServiceSpy.invokeRestServiceCall.and.returnValue(of(mockResponse));
    const spy = route.navigate as jasmine.Spy;
    component.onSubmit();
    const navArgs = spy.calls.first().args[0];
      expect(navArgs).toBe(true,
    'Should registrationSuccess is true');*/
  }));

  // Registration submission failure
  it(' Registration submission failure', async(() => {
    commonServiceSpy.invokeRestServiceCall.and.returnValue(of(mockResponse2));
     component.onSubmit();
     expect(component.message).toEqual('System/Application Error');
}));

});
