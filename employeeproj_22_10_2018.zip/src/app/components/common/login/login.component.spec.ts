import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { ShowErrorsComponent } from '../validation/validation-component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonService } from '../../../services/common.service';
import { APP_BASE_HREF } from '@angular/common';
import { Router } from '@angular/router';
import { LoginService } from '../../../services/login.service';
import { CommonModule } from '../../../modules/common.module';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { of } from 'rxjs';

class FakeActivatedRoute {
    params = Observable.create(obj => {
        obj.next({id: '123'});
        obj.complete();
    });
    queryParams = Observable.create(obj => {
        obj.next({id: '123'});
        obj.complete();
    });
}

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  const commonServiceSpy =
    jasmine.createSpyObj('CommonService', ['invokeRestServiceCall']);
    const loginServiceSpy =
    jasmine.createSpyObj('LoginService', ['processCustLoginAction']);
    const mockResponse  = {status: 'SUCCESS', result: { name: 'Admin'}};
    const mockResponse2  = {status: 'ERROR', message: 'System/Application Error'};
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent , ShowErrorsComponent],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule.withRoutes([])
      ],
      schemas: [ NO_ERRORS_SCHEMA ],
      providers: [{ provide: CommonService, useValue: commonServiceSpy },
        { provide: LoginService, useValue: loginServiceSpy },
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: Router,      useValue: routerSpy },
        { provide: ActivatedRoute, useClass: FakeActivatedRoute}
      ]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

   // Login submission failure
   it(' Login submission failure', async(() => {
    commonServiceSpy.invokeRestServiceCall.and.returnValue(of(mockResponse2));
     component.onSubmit();
     expect(component.message).toEqual('System/Application Error');
}));
});
