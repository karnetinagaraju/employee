import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../../../services/login.service';
import { CommonService } from '../../../services/common.service';
import { CustomValidators } from '../../../shared/validation-utilities';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  message = '';
  messageClass = 'alert-danger';

  constructor(
    private router: Router, private route: ActivatedRoute,
    private loginService: LoginService,
    private commonService: CommonService) { }

  ngOnInit() {
    this.loginForm = new FormGroup({
      'username': new FormControl(null,
        [Validators.required,
        Validators.minLength(4),
        Validators.maxLength(15)]),
      'password': new FormControl(null, [Validators.required]),
    });
    this.route.queryParams.subscribe(
      params => {
        if (params['registrationSuccess']) {
          this.message = 'Registeration is successful & Please login here!';
          this.messageClass = 'alert-success';
        }
    });
  }

  onSubmit() {
    this.message = '';
    this.messageClass = 'alert-danger';
    const resp: any = this.commonService.invokeRestServiceCall('user/validateUser', true, this.loginForm.value);
    resp.subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.loginService.processCustLoginAction(response.result);
          this.router.navigate(['/employee']);
        } else {
          this.message = response.message;
        }
      });
  }
}
