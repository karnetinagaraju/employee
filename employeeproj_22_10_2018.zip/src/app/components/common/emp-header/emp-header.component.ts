import { Component } from '@angular/core';
import { LoginService } from '../../../services/login.service';
@Component({
  selector: 'app-emp-header',
  templateUrl: './emp-header.component.html',
  styleUrls: ['./emp-header.component.css']
})
export class EmpHeaderComponent {
  constructor(private loginService: LoginService) { }
}
