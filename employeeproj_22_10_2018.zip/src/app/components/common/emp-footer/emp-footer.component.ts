import { Component } from '@angular/core';
@Component({
  selector: 'app-emp-footer',
  templateUrl: './emp-footer.component.html',
  styleUrls: ['./emp-footer.component.css']
})
export class EmpFooterComponent {
  constructor() { }
 }
