import { Component, Input } from '@angular/core';
import { AbstractControlDirective, AbstractControl } from '@angular/forms';
@Component({
  selector: 'app-show-errors',
  template: `
  <ul [hidden]="!shouldShowErrors()">
  <li class="errorMsg" *ngFor="let error of errMsgs">{{error}}</li>
</ul>
  `
})
export class ShowErrorsComponent  {
  @Input() control: AbstractControlDirective | AbstractControl;
  errMsgs = [];
  errorMessages = {
    'required': 'This Field is required',
    'maxlength': 'Maximumlenght should be 15 charcters',
    'minlength': 'Miniumlenght should be 4 charcters',
    'onlyAlphabet': 'Allows only aplabhets charcters',
    'email':  'email should contain the @ charcter .com as well',
    'unknown': 'Unknown Validation Error'
  };

  shouldShowErrors(): boolean {
    const flag: boolean = this.control &&
      this.control.errors &&
      (this.control.valid || this.control.dirty || this.control.touched);
    if (flag) {
      this.updateErrorMessages();
    }
    return flag;
  }
  private updateErrorMessages(): any {
    this.errMsgs = [];
    Object.keys(this.control.errors).forEach(keyError => {
      if (this.control.errors[keyError]) {
        if (this.errorMessages[keyError]) {
          this.errMsgs.push(this.errorMessages[keyError]);
        } else {
          this.errMsgs.push(this.errorMessages['unknown']);
        }
      }
    });
    return this.errMsgs;
  }
}

