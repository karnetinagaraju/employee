import { Component, OnInit } from '@angular/core';
import { Employee } from '../../../models/employee.model';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {
  empID: number;
  employees: Employee[];
  filteredEmployees: Employee[];
  private _searchTerm: string;
  private readonly headers = [
    { title: 'empId' },
    { title: 'name' },
    { title: 'username' },
    { title: 'address' },
    { title: 'email' },
    { title: 'mobile' },
    { title: '' },
    { title: '' }
  ];
  constructor(private commonService: CommonService) {  }

  ngOnInit() {
    this.getAllEmployees();
  }

  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(value: string) {
    this._searchTerm = value;
    this.filteredEmployees = this.filtereEmployees(value);
  }

  filtereEmployees(serachString: string) {
    console.log('inside the filtereEmployees ');
    return this.employees.filter(employee =>
      employee.username.toLowerCase().indexOf(serachString.toLowerCase()) !== -1
      || employee.address.toLowerCase().indexOf(serachString.toLowerCase()) !== -1);
  }

  getAllEmployees() {
    const resp: any = this.commonService.invokeRestServiceCall(
      'employee/getAll', false, null);
      resp.subscribe(
        (employees: any[]) => {
          console.log(employees);
          this.employees = employees;
          this.filteredEmployees = this.employees;
        }
      );
  }

  onDelete(empID) {
    console.log('emp id is is' + empID);
    const resp: any = this.commonService.invokeRestServiceCall(
      'employee/deleteData', true, { employee_id: empID });
    resp.subscribe(
        (data) => {
          this.getAllEmployees();
        },
        err => console.error('error is ********* ' + err),
        () => console.log('test get request')
      );
  }

}
