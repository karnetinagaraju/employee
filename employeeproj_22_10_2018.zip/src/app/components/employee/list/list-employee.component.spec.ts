import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListEmployeeComponent } from './list-employee.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonService } from '../../../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';


describe('ListEmployeeComponent', () => {
  let component: ListEmployeeComponent;
  let fixture: ComponentFixture<ListEmployeeComponent>;
  const commonServiceSpy =
    jasmine.createSpyObj('CommonService', ['invokeRestServiceCall']);
    const mockResponse  = {status: 'SUCCESS', result: { name: 'Admin'}};
    const mockResponse2  = {status: 'ERROR', message: 'System/Application Error'};
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListEmployeeComponent ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule.withRoutes([])
      ],
      schemas: [ NO_ERRORS_SCHEMA ],
      providers: [{ provide: CommonService, useValue: commonServiceSpy },

        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: Router,      useValue: routerSpy }

      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
