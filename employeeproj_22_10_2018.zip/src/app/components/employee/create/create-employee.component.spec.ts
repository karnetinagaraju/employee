import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { APP_BASE_HREF, CommonModule, Location } from '@angular/common';
import { CreateEmployeeComponent } from './create-employee.component';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonService } from '../../../services/common.service';
import { of } from 'rxjs';
// import { appRoutes } from '../../../modules/common.module';
import { Router } from '@angular/router';
import { ShowErrorsComponent } from '../../common/validation/validation-component';
import { EmployeeModule } from '../../../modules/employee.module';

describe('CreateEmployeeComponent', () => {
  let component: CreateEmployeeComponent;
  let fixture: ComponentFixture<CreateEmployeeComponent>;
  const commonServiceSpy =
    jasmine.createSpyObj('CommonService', ['invokeRestServiceCall']);
    const mockResponse  = {status: 'SUCCESS', result: { name: 'Admin'}};
    const mockResponse2  = {status: 'ERROR', message: 'System/Application Error'};
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

    beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        BrowserModule,
        FormsModule,
        CommonModule,
        EmployeeModule,
        /*RouterTestingModule.withRoutes(appRoutes),*/
        ReactiveFormsModule
      ],
      providers: [{ provide: CommonService, useValue: commonServiceSpy },
        { provide: APP_BASE_HREF, useValue: '/' },
        { provide: Router,      useValue: routerSpy }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // Component Should be created
  it('Component Should be created', async(() => {
    expect(component).toBeTruthy();
  }));


});
