import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Employee } from '../../../models/employee.model';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  createForm: FormGroup;
  employee: Employee[] = [];
  message = '';

  constructor(private commnService: CommonService,
    private router: Router) { }

  ngOnInit() {
    this.createForm = new FormGroup({
      'name': new FormControl(null,
        [Validators.required,
        Validators.minLength(4),
        Validators.maxLength(15)]),
      'mobile': new FormControl(null, [Validators.required]),
      'address': new FormControl(null, [Validators.required]),
      'username': new FormControl(null, [Validators.required,
      Validators.minLength(4),
      Validators.maxLength(15)]),
      'email': new FormControl(null, [Validators.required,
      Validators.email])
    });
  }

  onSubmit(createForm) {
    const resp: any = this.commnService.invokeRestServiceCall('employee/createData', true, this.createForm.value);
    resp.subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.router.navigate(['/employee/listEmployee']);
        } else {
          this.message = response.message;
        }
      }
    );
  }

}
