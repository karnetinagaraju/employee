import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { catchError, map } from 'rxjs/operators';
import { Observable, of, throwError } from 'rxjs';


@Injectable()
export class CommonService {
    constructor(private http: HttpClient) {
    }

   invokeRestServiceCall(url: string, isPostMethod: boolean, inputJson: any) {
        if (isPostMethod) {
            return this.http.post(environment.service_url_config.appurl + url,
                inputJson).pipe(catchError(this.handleError<any>(url)));
        } else if ( inputJson !== null ) {
           return this.http.get(environment.service_url_config.appurl + url,
            inputJson).pipe(catchError(this.handleError<any>(url)));
        } else {
            return this.http.get(environment.service_url_config.appurl + url
                ).pipe(catchError(this.handleError<any>(url)));
        }
    }


    /**
 * Handle Http operation that failed.
 * Let the app continue.
 * @param operation - name of the operation that failed
 * @param result - optional value to return as the observable result
 */
    private handleError<T>(operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {
            const result2: any = {};
            result2.status = 'ERROR';
            result2.message = 'System / Application Error';
            let httpResponse: HttpErrorResponse = null;
            if (error instanceof HttpErrorResponse) {
                httpResponse = error;
                if (httpResponse.statusText) {
                    // result2.message = httpResponse.statusText;
                }
            }
            return of(result2);
        };
    }
}
