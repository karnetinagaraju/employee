import { LoginService } from './login.service';
import { CommonService } from './common.service';
import { Observable, of, throwError } from 'rxjs';

describe('LoginService', () => {
    let service: LoginService;
    const commonServiceSpy =
    jasmine.createSpyObj('CommonService', ['invokeRestServiceCall']);
    const mockResponse  = {status: 'SUCCESS', result: { name: 'Admin'}};

    beforeEach(() => {
        localStorage.removeItem('currentUser');
        commonServiceSpy.invokeRestServiceCall.and.returnValue(of(mockResponse));
        service = new LoginService();
     });

    // Default Current User Should be null
    it('Default Current User Should be null', () => {
      expect(service.currentUser).toBe(null);
    });

    // Valid Current User after login
    it('Valid Current User after login', () => {
        service.processCustLoginAction({name: 'Admin', password: '123'});
        expect(service.currentUser).toEqual('Admin');
      });

     // Current User null after logout
     it('Current User null after logout', () => {
        service.processCustLoginAction({name: 'Admin'});
        expect(service.currentUser).toEqual('Admin');
        service.logout();
        expect(service.currentUser).toBe(null);
      });

  });
