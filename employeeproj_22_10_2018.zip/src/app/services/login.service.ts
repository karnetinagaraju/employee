import { Injectable } from '@angular/core';

@Injectable()
export class LoginService {
    currentUser = localStorage.getItem('currentUser');
    constructor() {}
    logout() {
       this.currentUser = null;
        localStorage.removeItem('currentUser');
    }
    processCustLoginAction(result: any) {
        this.currentUser = result.name;
        localStorage.setItem('currentUser', result.name);
    }
}
