import { AppLoginComponent } from './app-login.component';
import { LogService } from './log.service';

describe('AppLoginComponent', () => {
  let component: AppLoginComponent;
  let service: LogService;
  beforeEach(() => {

    service = new LogService();
    component = new AppLoginComponent(service);
  });

  afterEach(() => {
    localStorage.removeItem('token');
    service = null;
    component = null;
  });

  it('canLogin returns false when the user is not authenticated', () => {
    localStorage.setItem('token', '12345');
   // expect(component.needsLogin()).toBeFalsy();
    expect(component.needsLogin()).toBeFalsy();
  });
});
