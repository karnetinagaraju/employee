
export class LogService {
    isAunthicated(): boolean {
        const token = localStorage.getItem('token');
        console.log('Service inside ' + localStorage.getItem('token'));
        return !!localStorage.getItem('token');
    }
}

