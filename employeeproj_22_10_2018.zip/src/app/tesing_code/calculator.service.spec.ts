import { CalculatorService } from './calculator.service';
describe('CalculatorService:Class New Object', () => {
    let service: CalculatorService;
    beforeEach(() => {
        service = new CalculatorService();
     });

    it('Test Addition', () => {
        expect(service.add(2, 6)).toEqual(8);
    });
    it('Test Subtraction', () => {
        expect(service.subtract(8, 2)).toEqual(6);
    });
    it('Test Multiplication', () => {
        expect(service.multiply(2, 6)).toEqual(12);
    });
    it('Test Division', () => {
        expect(service.division(6, 2)).toEqual(3);
    });
});

describe('CalculatorService:Spy', () => {
    let service: any;
    beforeEach(() => {
        service = jasmine.createSpyObj('CalculatorService',
                ['add', 'subtract']);
        service.add.and.returnValue(10);
        service.subtract.and.returnValue(5);
    });

    it('Test Addition', () => {
        expect(service.add(2, 6)).toEqual(10);
    });

    it('Test Subtraction', () => {
        expect(service.subtract(8, 2)).toEqual(5);
    });
});

describe('CalculatorService: Mock/Stub Object', () => {
    const service: any = {
        add(a: number, b: number): number {
            return 0;
        }
    };
    beforeEach(() => {
    });

    it('Test Addition', () => {
        expect(service.add(2, 6)).toEqual(0);
    });

});

describe('CalculatorService: TestBenNgModule', () => {

});
