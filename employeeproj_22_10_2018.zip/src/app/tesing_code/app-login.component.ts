
import {Component} from '@angular/core';
import { LogService } from './log.service';
@Component({
  selector: 'app-login',
  template: `<a [hidden]="needsLogin()">Login</a>`
})
export class AppLoginComponent {
  constructor(private auth: LogService) {
  }
  needsLogin() {
    console.log(!this.auth.isAunthicated());
    return !this.auth.isAunthicated();
  }
}

